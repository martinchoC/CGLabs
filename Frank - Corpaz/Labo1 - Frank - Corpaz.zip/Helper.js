class Helper {

	/**
	 * Creates a vertex and a fragment shader based on the provided GLSL source code.
	 * Then it generates the program out of the 2 shaders and returns it.
	 * 
	 * @param {WebGL Context} gl
	 * @param {GLSL Source Code} vertex_shader_source
	 * @param {GLSL Source Code} fragment_shader_source
	 * @return {Shader Program} shader_program
	 */
	static generateProgram(gl, vertex_shader_source, fragment_shader_source) {

		// ----- Create Shaders ----- //

		let vertex_shader = gl.createShader(gl.VERTEX_SHADER);
		let fragment_shader = gl.createShader(gl.FRAGMENT_SHADER);
		
		gl.shaderSource(vertex_shader, vertex_shader_source); // (shader with type, source code)
		gl.shaderSource(fragment_shader, fragment_shader_source);

		gl.compileShader(vertex_shader)
		if (!gl.getShaderParameter(vertex_shader, gl.COMPILE_STATUS)) {
			console.error('ERROR compiling vertex shader!', gl.getShaderInfoLog(vertex_shader));
			return;
		}
		gl.compileShader(fragment_shader);
		if (!gl.getShaderParameter(fragment_shader, gl.COMPILE_STATUS)) {
			console.error('ERROR compiling fragment shader!', gl.getShaderInfoLog(fragment_shader));
			return;
		}

		// ----- Create Program ----- //

		let shader_program = gl.createProgram();
		gl.attachShader(shader_program, vertex_shader);
		gl.attachShader(shader_program, fragment_shader);
		gl.linkProgram(shader_program);
		if (!gl.getProgramParameter(shader_program, gl.LINK_STATUS)) {
			console.error('ERROR linking program!', gl.getProgramInfoLog(shader_program));
			return;
		}
		gl.validateProgram(shader_program);
		if (!gl.getProgramParameter(shader_program, gl.VALIDATE_STATUS)) {
			console.error('ERROR validating program!', gl.getProgramInfoLog(shader_program));
			return;
		}

		gl.deleteShader(vertex_shader);
		gl.deleteShader(fragment_shader);

		return shader_program;
	}
}
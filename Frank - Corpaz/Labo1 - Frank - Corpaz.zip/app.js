/*
* Universidad Nacional del Sur
* Computacion Grafica - 2018
*
* Andres Frank
* German Corpaz
* _____________________________
*/

// ----- Vertex Shader ----- //
function getVertexShaderSource() {
	return `
		attribute vec3 vertPosition; // [x, y, z] coordinates
		attribute vec3 vertColor; // [r, g, b]
		
		// matrices mat4= 4x4 matrix
		uniform mat4 worldM; 
		uniform mat4 viewM;
		uniform mat4 projM;

		void main() {
			gl_Position = projM * viewM * worldM * vec4(vertPosition, 1.0);
		}
	`;
}

// ----- Fragment Shader ----- //
function getFragmentShaderSource() {
	return `
		precision mediump float;

		uniform vec3 fragColor;
		 
		void main() {
			gl_FragColor = vec4(fragColor, 1);
		}
	`;
}

// ----- Global Variables ----- //
var gl = null; // The webgl context
var shader_program = null; // Shader program to use.
var modelEBO = null; // ElementBufferObject

var drone_indices_length = 0; // Array length to draw
var drone_parsedOBJ = null; // Our parsed OBJ model
var drone_vao = null;

var mesa_indices_length = 0; // Array length to draw
var mesa_parsedOBJ = null; // Our parsed OBJ model
var mesa_vao = null;


// Uniforms and helpers
var worldMatrix_location, worldMatrix_value;

var worldMatrix_value_mesa, worldMatrix_value_drone1, worldMatrix_value_drone2;

var viewMatrix_location, viewMatrix_value;
var projMatrix_location, projMatrix_value;

var drone_fragColor_location, drone1_fragColor_value, drone2_fragColor_value;
var mesa_fragColor_location, mesa_fragColor_value;

/*
 * We specified in the html <body> tag that this function is to be loaded as soon as the HTML loads.
 * This is all "initialization code", since it runs only once at load time to set up the workspace.
 */
function onLoad() {

	// ----- Set up the webgl environment ----- //
	let canvas = document.getElementById("webglcanvas");
	gl = canvas.getContext('webgl');
	if (!gl) {
		console.log('WebGL not supported, falling back on experimental-webgl');
		gl = canvas.getContext('experimental-webgl');
	}
	if (!gl) alert('Your browser does not support WebGL');
	
	vaoExtension = gl.getExtension('OES_vertex_array_object');


	// ----- Parse OBJ Files ----- //
	
	drone_parsedOBJ = OBJParser.parseFile(droneOBJSource); 
	let drone_parsedOBJ_indices = drone_parsedOBJ.indices;
	drone_indices_length = drone_parsedOBJ_indices.length;
	let drone_parsedOBJ_positions = drone_parsedOBJ.positions;


	mesa_parsedOBJ = OBJParser.parseFile(mesaOBJSource); 
	let mesa_parsedOBJ_indices = mesa_parsedOBJ.indices;
	mesa_indices_length = mesa_parsedOBJ_indices.length;
	let mesa_parsedOBJ_positions = mesa_parsedOBJ.positions;


	// ----- Create the shaders and program ----- //
	shader_program = Helper.generateProgram(gl, getVertexShaderSource(), getFragmentShaderSource());



	// ----- Create Buffers del DRONE----- //

	// -- Create Vertex Array Object (VAO): Contains the EBO and multiple VBOs
	drone_vao = vaoExtension.createVertexArrayOES(); //create
	vaoExtension.bindVertexArrayOES(drone_vao); //begin setting up


	// -- Create Vertex Buffer Object (VBO): Contains information on positions, colors, textures, etc.

	let vboPosition = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, vboPosition);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(drone_parsedOBJ_positions), gl.STATIC_DRAW); 

	let vertPositionAttribLocation = gl.getAttribLocation(shader_program, 'vertPosition');
	gl.vertexAttribPointer(
		vertPositionAttribLocation, // Attribute location
		3, // Number of elements per attribute (here is a vec2=[x,y])
		gl.FLOAT, // Type of elements
		gl.FALSE, // whether or not the data should be normalized
		0, // 0 = move forward size * sizeof(type) each iteration to get the next position.
		0 // Offset from the beginning of a single vertex to this attribute
	);
	gl.enableVertexAttribArray(vertPositionAttribLocation); 

	// -- Fragment Shader Uniform Color
	drone_fragColor_location = gl.getUniformLocation(shader_program, 'fragColor');

	// -- Create Element Buffer Object (EBO): Contains the indices
	
	modelEBO = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, modelEBO);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(drone_parsedOBJ_indices), gl.STATIC_DRAW);
	
	vaoExtension.bindVertexArrayOES(null); 
	gl.bindBuffer(gl.ARRAY_BUFFER, null);
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null); // Best practices: clean-up.



	// ----- Create Buffers de la mesa----- //

	// -- Create Vertex Array Object (VAO): Contains the EBO and multiple VBOs
	mesa_vao = vaoExtension.createVertexArrayOES(); //create
	vaoExtension.bindVertexArrayOES(mesa_vao); //begin setting up

	// -- Create Vertex Buffer Object (VBO): Contains information on positions, colors, textures, etc.

	let mesa_vboPosition = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, mesa_vboPosition);
	gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(mesa_parsedOBJ_positions), gl.STATIC_DRAW); 

	let mesa_vertPositionAttribLocation = gl.getAttribLocation(shader_program, 'vertPosition');
	gl.vertexAttribPointer(
		mesa_vertPositionAttribLocation, // Attribute location
		3, // Number of elements per attribute (here is a vec2=[x,y])
		gl.FLOAT, // Type of elements
		gl.FALSE, // whether or not the data should be normalized
		0, // 0 = move forward size * sizeof(type) each iteration to get the next position.
		0 // Offset from the beginning of a single vertex to this attribute
	);
	gl.enableVertexAttribArray(mesa_vertPositionAttribLocation); 


	// -- Fragment Shader Uniform Color
	mesa_fragColor_location = gl.getUniformLocation(shader_program, 'fragColor');

	// -- Create Element Buffer Object (EBO): Contains the indices
	mesa_modelEBO = gl.createBuffer();
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesa_modelEBO);
	gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(mesa_parsedOBJ_indices), gl.STATIC_DRAW);
	
	vaoExtension.bindVertexArrayOES(null); 
	gl.bindBuffer(gl.ARRAY_BUFFER, null);
	gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, null); // Best practices: clean-up.


	// ----- Define World/View/Projection Matrices ----- //

	worldMatrix_location = gl.getUniformLocation(shader_program, 'worldM');
	viewMatrix_location = gl.getUniformLocation(shader_program, 'viewM');
	projMatrix_location = gl.getUniformLocation(shader_program, 'projM');

	// creates them with the identity matrix, so they don't perform any transform yet.
	viewMatrix_value = mat4.create();
	projMatrix_value = mat4.create();


	let auxmatrix_scale, auxmatrix_translate, auxmatrix_rotate;

	// --------  TRANSFORMACIONES DE LA MESA
	mesa_fragColor_value = vec3.fromValues(1, 0, 0);

	worldMatrix_value_mesa = mat4.create();
	mat4.scale(worldMatrix_value_mesa, worldMatrix_value_mesa, [0.02, 0.02, 0.02]);


	// --------  TRANSFORMACIONES DEL DRONE 1
	drone1_fragColor_value = vec3.fromValues(0, 1, 0);

	worldMatrix_value_drone1 = mat4.create();
	auxmatrix_scale = mat4.create();
	auxmatrix_translate = mat4.create();
	
	mat4.translate(auxmatrix_translate, auxmatrix_translate, [0, 1.5, 0]);
	
	matrixaux_scale = mat4.create();
	mat4.scale(auxmatrix_scale, auxmatrix_scale, [0.02, 0.02, 0.02]);

	mat4.multiply(worldMatrix_value_drone1, auxmatrix_translate, auxmatrix_scale);


	// -------- TRANSFORMACIONES DEL DRONE 2
	drone2_fragColor_value = vec3.fromValues(0, 0, 1);

	worldMatrix_value_drone2 = mat4.create();
	auxmatrix_scale = mat4.create();
	auxmatrix_translate = mat4.create();
	auxmatrix_rotate = mat4.create();

	
	mat4.translate(auxmatrix_translate, mat4.create(), [1.5, 1.9, 0]);
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_translate);

	mat4.scale(auxmatrix_scale, auxmatrix_scale, [0.01, 0.01, 0.01]);
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_scale);

	mat4.rotateX(auxmatrix_rotate, mat4.create(), glMatrix.toRadian(90));
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_rotate);

	mat4.rotateZ(auxmatrix_rotate, mat4.create(), glMatrix.toRadian(90));
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_rotate);


/*
	mat4.scale(auxmatrix_scale, auxmatrix_scale, [0.01, 0.01, 0.01]);
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_scale);

	mat4.rotateX(auxmatrix_rotate, mat4.create(), glMatrix.toRadian(90));
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_rotate);

	mat4.rotateZ(auxmatrix_rotate, mat4.create(), glMatrix.toRadian(90));
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_rotate);
	
	mat4.translate(auxmatrix_translate, mat4.create(), [0, 100.9, -190]);
	mat4.multiply(worldMatrix_value_drone2, worldMatrix_value_drone2, auxmatrix_translate);

*/


	mat4.perspective(
		projMatrix_value, 		// the matrix that will be edited
		glMatrix.toRadian(45), 	// fovy: vertical field of view in radians
		1, 						// aspect ratio
		0.1, 					// zNear
		100.0, 					// zFar
	);

	// -- Defining the camera (viewMatrix)
	configureCamera();

	// ----- Set up rendering -----
	gl.clearColor(0.18, 0.18, 0.18, 1.0); // Background Color (R, G, B, Alpha)

	// Enable the needed rendering tests so it draws correctly	
	gl.enable(gl.DEPTH_TEST);
	gl.enable(gl.CULL_FACE);
	gl.frontFace(gl.CCW);
	gl.cullFace(gl.BACK);

	render();	
}



/**
 * Draw on the screen
 */
function render() {

	// Tell OpenGL state machine which program should be active.
	gl.useProgram(shader_program);

	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	// --------- UPDATE MATRICES	
	gl.uniformMatrix4fv(viewMatrix_location, gl.FALSE, viewMatrix_value);
	gl.uniformMatrix4fv(projMatrix_location, gl.FALSE, projMatrix_value);


	// ---------- DRAW THE TABLE
	vaoExtension.bindVertexArrayOES(mesa_vao);

	gl.uniform3fv(mesa_fragColor_location, mesa_fragColor_value);
	gl.uniformMatrix4fv(worldMatrix_location, gl.FALSE, worldMatrix_value_mesa);

	gl.drawElements(gl.TRIANGLES, mesa_indices_length, gl.UNSIGNED_SHORT, 0);
	vaoExtension.bindVertexArrayOES(null);


	// ---------- DRAW DRONE 1
	vaoExtension.bindVertexArrayOES(drone_vao);

	gl.uniform3fv(drone_fragColor_location, drone1_fragColor_value);
	gl.uniformMatrix4fv(worldMatrix_location, gl.FALSE, worldMatrix_value_drone1);

	gl.drawElements(gl.TRIANGLES, drone_indices_length, gl.UNSIGNED_SHORT, 0);
	vaoExtension.bindVertexArrayOES(null);


	// ---------- DRAW DRONE 2
	vaoExtension.bindVertexArrayOES(drone_vao);

	gl.uniform3fv(drone_fragColor_location, drone2_fragColor_value);
	gl.uniformMatrix4fv(worldMatrix_location, gl.FALSE, worldMatrix_value_drone2);

	gl.drawElements(gl.TRIANGLES, drone_indices_length, gl.UNSIGNED_SHORT, 0);
	vaoExtension.bindVertexArrayOES(null);

	gl.useProgram(null); 
}


// ----- Camera Module ----- //

var camera_radius;
var camera_theta;
var camera_phi;

function configureCamera() {
	// set the default values
	camera_radius = 7;
	camera_theta = 180;//degrees
	camera_phi = 5;//degrees
	
	// Update the HTML tags with these default values.
	document.getElementById("lblRadius").innerText = camera_radius;
	document.getElementById("lblTheta").innerText = camera_theta;
	document.getElementById("lblPhi").innerText = camera_phi;

	// Generate the ViewMatrix
	updateCamera();
}

function updateCamera() {

	let _camera_eye = toCartesianArray(camera_radius, camera_theta, camera_phi);

	mat4.lookAt(
		viewMatrix_value, // Where to store the resulting matrix
		_camera_eye,// Eye: Where is the camera
		[0, 0, 0], 	// Target: Where is it looking
		[0, 1, 0] 	// UP: Which side is up (here the Y+ coord means up)
	);
}

/**
 * Goes from spherical coordinates [r,theta,phi] into cartesians [x,y,z]
 * params theta and phi are in degrees
 * @return {3-component vector} A vector containing the X, Y and Z coordinates in cartesian form.
 */
function toCartesianArray(radius, theta, phi) {
	let _theta = glMatrix.toRadian(theta);
	let _phi = glMatrix.toRadian(phi);

	let x = radius * Math.sin(_phi) * Math.cos(_theta);
	let z = radius * Math.sin(_phi) * Math.sin(_theta);
	let y = radius * Math.cos(_phi);
	
	return [x, y, z];
}

/**
 * HTML Keyboard listener
 * @param  evt: the event generated by the HTML
 */
function onKeyDown(evt) {

	switch(evt.code) {

		case "KeyQ":
			if (camera_radius < 20) { // limit of where the camera can move
				camera_radius = camera_radius + 1;
				document.getElementById("lblRadius").innerText = camera_radius;
			}
			break;

		case "KeyE":
			if (camera_radius > -20) {
				camera_radius = camera_radius - 1;
				document.getElementById("lblRadius").innerText = camera_radius;
			}
			break;

		case "KeyD":
			if (camera_theta < 360) {
				camera_theta = camera_theta + 5;
				document.getElementById("lblTheta").innerText = camera_theta;
			}
			break;

		case "KeyA":
			if (camera_theta > 0) {
				camera_theta = camera_theta - 5;
				document.getElementById("lblTheta").innerText = camera_theta;
			}
			break;

		case "KeyW":
			if (camera_phi < 360) {
				camera_phi = camera_phi + 5;
				document.getElementById("lblPhi").innerText = camera_phi;
			}
			break;

		case "KeyS":
			if (camera_phi > 5) {
				camera_phi = camera_phi - 5;
				document.getElementById("lblPhi").innerText = camera_phi;
			}
			break;
	}

	updateCamera();
	render();
}
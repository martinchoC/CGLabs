class Object {
	constructor(objectSource) {
		this.source = objectSource;
		this.vaoSolid = []; //Geometry to render (stored in VAO).
        this.vaoWire = [];
		this.indexCountSolid = [];
        this.indexCountWire = [];
        //this.modelMatrix = mat4.create(); // Indentity matrix
        this.modelMatrix = [];
        this.cantMallas = 0;
        this.nombreMalla = [];
	}

	generateModel(pos_location) {
		let parsedOBJ = OBJParser2.parseFile(this.source);
		//Se trata de un objeto con varias mallas
		this.cantMallas = parsedOBJ.length;
		for(var i=0; i<this.cantMallas;i++){
			let indicesSolid = parsedOBJ[i].indices;
			let indicesWire = Utils.reArrangeIndicesToRenderWithLines(indicesSolid);
			this.indexCountSolid[i] = indicesSolid.length;
			this.indexCountWire[i] = indicesWire.length;
			var positions = parsedOBJ[i].positions;

			let vertexAttributeInfoArray = [
				new VertexAttributeInfo(positions, this.pos_location, 3)
			];
		
			this.vaoSolid[i] = VAOHelper.create(indicesSolid, vertexAttributeInfoArray);
			this.vaoWire[i] = VAOHelper.create(indicesWire, vertexAttributeInfoArray);
			this.modelMatrix[i] = mat4.create();
			this.nombreMalla[i] = parsedOBJ[i].name;
			//console.log(this.nombreMalla[i] + " ");
		}
		//Ya tengo los buffers cargados en memoria de la placa grafica, puedo borrarlo de JS
		parsedOBJ = null;
	}

	setModelMatrix(matrix, i) {
		this.modelMatrix[i] = matrix;
	}

	setModelMatrixByName(matrix, name){
		for(var i=0; i<this.cantMallas; i++){
			if(name == this.nombreMalla[i]){
				this.modelMatrix[i] = matrix;
			}
		}

	}

	setAllModelMatrix(matrix){
		for(var k=0; k<this.cantMallas; k++){
			this.modelMatrix[k] = matrix;
		}

	}

	draw(solid, gl, _gl) {
		for(var j=0; j<this.cantMallas; j++){
			// Set the model matrix of the object
			gl.uniformMatrix4fv(u_modelMatrix, false, this.modelMatrix[j]);

			// Draw object
			if (solid) {
				_gl.bindVertexArrayOES(this.vaoSolid[j]);
				gl.drawElements(gl.TRIANGLES, this.indexCountSolid[j], gl.UNSIGNED_INT, 0);	
			} else {
				_gl.bindVertexArrayOES(this.vaoWire[j]);
				gl.drawElements(gl.LINES, this.indexCountWire[j], gl.UNSIGNED_INT, 0);
			}
		}
		
	}

}
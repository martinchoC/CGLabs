// WebGL context and extensions
var gl = null;
var _gl = null;//This extension is to support VAOs in webgl1. (In webgl2, functions are called directly to gl object.)

//Shader program
var shaderProgram  = null; 

//Uniform locations.
var u_modelMatrix;
var u_viewMatrix;
var u_projMatrix;
var u_modelColor;

//Uniform values.
var modelColor = Utils.hexToRgbFloat("#FFFFFF");

//Objects (OBJ)
var cubo;
var esfera;
var cilindro;
var cono;
var toroide;
var mono;
var ironman;
var fan;
var heli;
var drone;
var mesa;

// Auxiliary objects
var axis;
var angulo = 0;

// Camera
var camera;

// Flags
var isSolid = false;
var animar = false;

function loadObjects(pos_location) {
	// Load each object (OBJ) and generate its mesh
	/**
	mono = new Object(monoSource, pos_location);
	mono.generateModel();

	esfera = new Object(esferaSource, pos_location);
	esfera.generateModel();

	cono = new Object(conoSource, pos_location);
	cono.generateModel();

	ironman = new Object(ironmanSource, pos_location);
	ironman.generateModel();
	
	fan = new Object(fanSource, pos_location);
	fan.generateModel();	

	heli = new Object(heliSource, pos_location);
	heli.generateModel();

	drone = new Object(droneSource, pos_location);
	drone.generateModel();

	mesa = new Object(mesaSource, pos_location);
	mesa.generateModel();
	*/

	drone = new Object(droneSource, pos_location);
	drone.generateModel();

	mesa = new Object(mesaSource, pos_location);
	mesa.generateModel();
	
	
}

function setObjectsTransformations(angle) {
	let matrix = mat4.create();
	let translation = mat4.create();
	let scaling = mat4.create();
	let rotation = mat4.create();
	angle = angle *20;
	//Drone 1
	//Vertices inicial de las helices

	//Giro paleta 1
	//1= [-24.4, 7.7, -26]
	let rotacionRotor1 = mat4.create();
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	rotation = mat4.create();
	mat4.fromTranslation(translation, [24.4, -7.7, -26]);
	mat4.fromRotation(rotation, angle, [0, 1, 0]);
	mat4.multiply(rotacionRotor1, rotation, translation);
	mat4.fromTranslation(translation, [-24.4, 7.7, 26]);
	mat4.multiply(rotacionRotor1, translation, rotacionRotor1);

	//Giro paleta 2
	//2 = [-24.4, 7.7, -19.5]
	let rotacionRotor2 = mat4.create();
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	rotation = mat4.create();
	mat4.fromTranslation(translation, [24.4, -7.7, 19.5]);
	mat4.fromRotation(rotation, angle, [0, 1, 0]);
	mat4.multiply(rotacionRotor2, rotation, translation);
	mat4.fromTranslation(translation, [-24.4, 7.7, -19.5]);
	mat4.multiply(rotacionRotor2, translation, rotacionRotor2);

	//Giro paleta 3
	//3= [21.6, 7.7, -19.5]
	let rotacionRotor3 = mat4.create();
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	rotation = mat4.create();
	mat4.fromTranslation(translation, [-21.6, -7.7, 19.5]);
	mat4.fromRotation(rotation, angle, [0, 1, 0]);
	mat4.multiply(rotacionRotor3, rotation, translation);
	mat4.fromTranslation(translation, [21.6, 7.7, -19.5]);
	mat4.multiply(rotacionRotor3, translation, rotacionRotor3);

	//Giro paleta 4
	//4= [21.6, 7.7, 26]
	let rotacionRotor4 = mat4.create();
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	rotation = mat4.create();
	mat4.fromTranslation(translation, [-21.6, -7.7, -26]);
	mat4.fromRotation(rotation, angle, [0, 1, 0]);
	mat4.multiply(rotacionRotor4, rotation, translation);
	mat4.fromTranslation(translation, [21.6, 7.7, 26]);
	mat4.multiply(rotacionRotor4, translation, rotacionRotor4);
	
	translation = mat4.create();
	scaling = mat4.create();
	mat4.fromScaling(scaling, [0.005, 0.005, 0.005]);
	mat4.fromTranslation(translation, [0.0, 0.7, 0.0]);
	mat4.multiply(matrix, translation, scaling);
	//mat4.fromRotation(rotation, angle, [0.0, 1.0, 0.0]);
	//mat4.multiply(matrix,matrix, rotacionRotor);
	drone.setAllModelMatrix(matrix);

	let aux1 = mat4.create();
	let aux2 = mat4.create();
	let aux3 = mat4.create();
	let aux4 = mat4.create();
	mat4.multiply(aux1, matrix, rotacionRotor1);
	mat4.multiply(aux2, matrix, rotacionRotor2);
	mat4.multiply(aux3, matrix, rotacionRotor3);
	mat4.multiply(aux4, matrix, rotacionRotor4);
	drone.setModelMatrixByName(aux1,"Rotor1");
	drone.setModelMatrixByName(aux2,"Rotor2");
	drone.setModelMatrixByName(aux3,"Rotor3");
	drone.setModelMatrixByName(aux4,"Rotor4");
	//Color
	let _modelColor = vec3.fromValues(0, 1, 0);
	gl.uniform3fv(u_modelColor, _modelColor);
	drone.draw(isSolid, gl, _gl);
	//Resetea color a blanco
	_modelColor = vec3.fromValues(1, 1, 1); //Blanco
	gl.uniform3fv(u_modelColor, _modelColor);
	
	//Drone 2
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	rotation = mat4.create();
	mat4.fromScaling(scaling, [0.0075, 0.0075, 0.0075]);
	mat4.fromTranslation(translation, [-0.6, 0.7+0.37, -0.4]);
	mat4.fromRotation(rotation, glMatrix.toRadian(90), [1, 0, 0]);
	mat4.multiply(matrix, rotation, scaling);
	mat4.multiply(matrix, translation, matrix);
	drone.setAllModelMatrix(matrix);

	mat4.multiply(rotacionRotor1, matrix, rotacionRotor1);
	mat4.multiply(rotacionRotor2, matrix, rotacionRotor2);
	mat4.multiply(rotacionRotor3, matrix, rotacionRotor3);
	mat4.multiply(rotacionRotor4, matrix, rotacionRotor4);
	drone.setModelMatrixByName(rotacionRotor1,"Rotor1");
	drone.setModelMatrixByName(rotacionRotor2,"Rotor2");
	drone.setModelMatrixByName(rotacionRotor3,"Rotor3");
	drone.setModelMatrixByName(rotacionRotor4,"Rotor4");

	//Color
	_modelColor = vec3.fromValues(0, 0.5, 1);
	gl.uniform3fv(u_modelColor, _modelColor);
	drone.draw(isSolid, gl, _gl);
	//Resetea color a blanco
	_modelColor = vec3.fromValues(1, 1, 1); //Blanco
	gl.uniform3fv(u_modelColor, _modelColor);

	//Mesa
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	rotation = mat4.create();
	mat4.fromScaling(scaling, [0.01, 0.01, 0.01]);
	//Vertice esquina [-0.7, 0.3, 0.7]
	mesa.setAllModelMatrix(scaling);
	//Color
	_modelColor = vec3.fromValues(0.7, 0.7, 0.7);
	gl.uniform3fv(u_modelColor, _modelColor);
	mesa.draw(isSolid, gl, _gl);
	//Resetea color a blanco
	_modelColor = vec3.fromValues(1, 1, 1); //Blanco
	gl.uniform3fv(u_modelColor, _modelColor);

	/**
	

	//Set Fan
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	mat4.fromTranslation(translation, [0.0, -0.4, 0.0]);
	mat4.fromRotation(rotation, angle, [0.0, 0.0, 1.0]);
	mat4.multiply(matrix,rotation,translation);
	mat4.fromTranslation(translation, [0.0, 0.4, 0.0]);
	mat4.multiply(matrix,translation,matrix);
	fan.setModelMatrix(matrix,1);

	//Helicoptero
	matrix = mat4.create();
	translation = mat4.create();
	scaling = mat4.create();
	mat4.fromScaling(scaling, [0.25, 0.25, 0.25]);
	mat4.fromRotation(rotation, -Math.PI /2, [1.0, 0.0, 0.0]);
	mat4.multiply(matrix,rotation,scaling);
	mat4.fromRotation(rotation, Math.PI, [0.0, 1.0, 0.0]);
	mat4.multiply(matrix,rotation,matrix);
	mat4.fromTranslation(translation, [0.0, 0.4, 0.0]);
	mat4.multiply(matrix,translation,matrix);
	heli.setAllModelMatrix(matrix);
	//Movimiento del rotor principal solamente
	rotation = mat4.create();
	mat4.fromRotation(rotation, angle, [0.0, 1.0, 0.0]);
	mat4.multiply(rotation,rotation,matrix);
	heli.setModelMatrixByName(rotation, "main_rotor"); //8 = main_rotor
	//Movimiento del rear_rotor
	let aux = mat4.create();
	translation = mat4.create();
	rotation = mat4.create();
	mat4.fromTranslation(translation, [0.11, -0.99, 2.6]); //muevo al origen[0,0,10.39]
	mat4.multiply(aux,translation,matrix);
	mat4.fromRotation(rotation, angle, [1.0, 0.0, 0.0]); //rotacion
	mat4.multiply(aux,rotation,aux);
	mat4.fromTranslation(translation, [-0.11, 0.99, -2.6]); //vuelvo cada punto a su lugar
	mat4.multiply(aux,translation,aux);
	heli.setModelMatrixByName(aux, "rear_rotor"); //7 = rear_rotor
*/
}

function onLoad() {
	let canvas = document.getElementById('webglCanvas');
	gl = canvas.getContext('webgl');
	_gl = VAOHelper.getVaoExtension();

	//SHADERS
	//vertexShaderSource y fragmentShaderSource estan importadas en index.html <script>
	shaderProgram = ShaderProgramHelper.create(vertexShaderSource, fragmentShaderSource);

	let posLocation = gl.getAttribLocation(shaderProgram, 'vertexPos');
	u_modelMatrix = gl.getUniformLocation(shaderProgram, 'modelMatrix');
	u_viewMatrix = gl.getUniformLocation(shaderProgram, 'viewMatrix');
	u_projMatrix = gl.getUniformLocation(shaderProgram, 'projMatrix');
	u_modelColor = gl.getUniformLocation(shaderProgram, 'modelColor');

	// Load all the objects
	loadObjects(posLocation);
	
	// Set the objects' transformations
	//setObjectsTransformations();

	// Set some WebGL properties
	gl.enable(gl.DEPTH_TEST);
	gl.clearColor(0.18, 0.18, 0.18, 1.0);
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	// Create auxiliary objects
	axis = new Axis();
	axis.load();
	
	// Create the camera using canvas dimension
	//camera = new SphericalCamera(55, 800/600);
	camera = new QuatCamera(55, 800/600);


}

var onRender = function () {
	let modelMatrix = mat4.create(); 
	let viewMatrix = camera.getViewMatrix();
	let projMatrix = camera.getProjMatrix();

	// Set some WebGL properties
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
	
	// Draw auxiliary objects
	axis.render(projMatrix, viewMatrix);

	// Set shader and uniforms
	gl.useProgram(shaderProgram);
	gl.uniformMatrix4fv(u_modelMatrix, false, modelMatrix);
	gl.uniformMatrix4fv(u_viewMatrix, false, viewMatrix);
	gl.uniformMatrix4fv(u_projMatrix, false, projMatrix);
	let _modelColor = vec3.fromValues(modelColor.r, modelColor.g, modelColor.b);
	gl.uniform3fv(u_modelColor, _modelColor);

	if(animar){
		angle = performance.now() / 1000 / 6 * 2 * Math.PI; //now(): da el tiempo transcurrido desde que se inicio la pag en milisegundos
	}
	else{
		angle = 0;
	}
	setObjectsTransformations(angle);
	
	//Draw objects
	//mono.draw(isSolid, gl, _gl);
	//esfera.draw(isSolid, gl, _gl);
	//ironman.draw(isSolid, gl, _gl);
	//cono.draw(isSolid, gl, _gl);
	//fan.draw(isSolid, gl, _gl);
	//heli.draw(isSolid, gl, _gl);
	//drone.draw(isSolid, gl, _gl);

	if(animar){
		requestAnimationFrame(onRender);
	}
	/*
	// Clean
	_gl.bindVertexArrayOES(null);
	gl.useProgram(null);
	*/
}

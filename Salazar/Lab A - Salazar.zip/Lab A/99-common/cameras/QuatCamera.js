
class QuatCamera extends Camera{

	constructor(fovy, aspect) {
		super(fovy, aspect);
		this.r = 2.5;
		this.anguloRot = 0.1; //rad
		this.cameraRot = quat.create();
	}

	getViewMatrix(){
		let eye = [this.r, this.r, this.r];
		let target = [0, 0, 0];
		let up = [0, 1, 0];
		//up x eye = [4,0,-4]
		let matFromQuat = mat4.create();
		mat4.fromQuat(matFromQuat, this.cameraRot);
		mat4.lookAt(this.viewMatrix, eye, target, up);
		mat4.multiply(this.viewMatrix, this.viewMatrix, matFromQuat);
		return this.viewMatrix;
	}

	rotarHorizontal(signoAngulo){
		//Rota con respecto al eje y. Porque apunta hacia arriba
		let tmpQuat = quat.create();
      	quat.rotateY(tmpQuat, tmpQuat, this.anguloRot * signoAngulo);
      	//quat.rotateY(this.cameraRot, this.cameraRot, this.anguloRot * signoAngulo);
      	quat.mul(this.cameraRot, tmpQuat, this.cameraRot);
	}

	rotarVertical(signoAngulo){
		let tmpQuatX = quat.create();
		let tmpQuatZ = quat.create();
      	quat.rotateX(tmpQuatX, tmpQuatX, this.anguloRot * -signoAngulo );
      	quat.rotateZ(tmpQuatZ, tmpQuatZ, this.anguloRot * signoAngulo );
      	quat.mul(tmpQuatX, tmpQuatX, tmpQuatZ);
      	quat.mul(this.cameraRot, tmpQuatX, this.cameraRot);
	}

	getRadius(){
		return this.r;
	}

	setRadius(r){
		this.r = r;
	}
}